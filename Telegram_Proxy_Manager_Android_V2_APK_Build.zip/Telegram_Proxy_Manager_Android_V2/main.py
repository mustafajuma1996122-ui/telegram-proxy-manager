
# -*- coding: utf-8 -*-
import json, os, re, socket, threading, time, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from kivy.app import App
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.checkbox import CheckBox
from kivy.uix.popup import Popup

SOURCES = [
    "https://raw.githubusercontent.com/ALIILAPRO/mtproto/master/all_proxies.txt",
    "https://raw.githubusercontent.com/hookzof/socks5_list/master/tg/mtproto.txt",
]

def parse_proxy(line):
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if line.startswith("tg://"):
        q = urllib.parse.parse_qs(urllib.parse.urlparse(line).query)
        server, port, secret = (q.get("server") or [""])[0], (q.get("port") or [""])[0], (q.get("secret") or [""])[0]
    else:
        parts = re.split(r"[\s,:]+", line)
        if len(parts) < 3:
            return None
        server, port, secret = parts[:3]
    try:
        port = int(port)
    except ValueError:
        return None
    if not server or not 1 <= port <= 65535 or not re.fullmatch(r"[0-9a-fA-F]{32,}", secret):
        return None
    return {"server": server, "port": port, "secret": secret.lower()}

def pkey(p):
    return p["server"].lower(), p["port"], p["secret"].lower()

def link(p):
    return "tg://proxy?" + urllib.parse.urlencode({"server": p["server"], "port": p["port"], "secret": p["secret"]})

def tcp_test(p):
    start = time.perf_counter()
    try:
        with socket.create_connection((p["server"], p["port"]), timeout=4):
            return True, round((time.perf_counter() - start) * 1000)
    except OSError:
        return False, None

class ProxyManager(App):
    def build(self):
        self.title = "Telegram Proxy Manager V2"
        self.data_file = os.path.join(self.user_data_dir, "proxies.json")
        self.items, self.selected = [], set()
        self.auto = True
        self.fetching = self.testing = False
        self.load()
        root = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(7))
        root.add_widget(Label(text="Telegram Proxy Manager  •  V2.0", size_hint_y=None, height=dp(42), bold=True, font_size="18sp"))
        buttons = GridLayout(cols=2, size_hint_y=None, height=dp(190), spacing=dp(5))
        actions = [
            ("جلب / تحديث", self.fetch),
            ("فحص الكل", self.check_all),
            ("أسرع بروكسي", self.open_fastest),
            ("فتح المحدد", self.open_selected),
            ("إضافة يدوية", self.add_manual),
            ("حذف المحدد", self.delete_selected),
            ("تحديث تلقائي: تشغيل", self.toggle_auto),
            ("تصدير TXT", self.export),
        ]
        for title, callback in actions:
            b = Button(text=title)
            b.bind(on_release=lambda _b, cb=callback: cb())
            buttons.add_widget(b)
        root.add_widget(buttons)
        bar = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(5))
        self.search = TextInput(hint_text="بحث Server أو IP", multiline=False)
        self.search.bind(text=lambda *_: self.render())
        self.filter = Spinner(text="الكل", values=["الكل", "متاح TCP", "غير متاح", "غير مفحوص"], size_hint_x=None, width=dp(125))
        self.filter.bind(text=lambda *_: self.render())
        bar.add_widget(self.search); bar.add_widget(self.filter)
        root.add_widget(bar)
        scroll = ScrollView()
        self.rows = GridLayout(cols=1, spacing=dp(5), size_hint_y=None)
        self.rows.bind(minimum_height=self.rows.setter("height"))
        scroll.add_widget(self.rows)
        root.add_widget(scroll)
        self.summary = Label(text="", size_hint_y=None, height=dp(25))
        root.add_widget(self.summary)
        self.status = Label(text="جاهز", size_hint_y=None, height=dp(32))
        root.add_widget(self.status)
        Clock.schedule_once(lambda *_: self.render(), 0)
        Clock.schedule_once(lambda *_: self.fetch(silent=True), 2)
        Clock.schedule_interval(self.auto_tick, 300)
        return root

    def load(self):
        try:
            with open(self.data_file, encoding="utf-8") as f:
                self.items = json.load(f).get("proxies", [])
        except Exception:
            self.items = []

    def save(self):
        os.makedirs(self.user_data_dir, exist_ok=True)
        with open(self.data_file, "w", encoding="utf-8") as f:
            json.dump({"proxies": self.items}, f, ensure_ascii=False, indent=2)

    def auto_tick(self, _dt):
        if self.auto and not self.fetching:
            self.fetch(silent=True)

    def toggle_auto(self):
        self.auto = not self.auto
        self.status.text = "التحديث التلقائي مفعل كل 5 دقائق" if self.auto else "التحديث التلقائي متوقف"

    def render(self):
        self.rows.clear_widgets()
        term, filt = self.search.text.lower().strip(), self.filter.text
        ordered = sorted(self.items, key=lambda p: (p.get("latency") is None, p.get("latency") or 999999))
        for p in ordered:
            state = p.get("status", "غير مفحوص")
            if filt != "الكل" and filt != state:
                continue
            if term and term not in (p["server"] + str(p["port"])).lower():
                continue
            row = BoxLayout(size_hint_y=None, height=dp(58), spacing=dp(5), padding=dp(5))
            check = CheckBox(size_hint_x=None, width=dp(40))
            check.active = pkey(p) in self.selected
            check.bind(active=lambda _c, value, k=pkey(p): self.selected.add(k) if value else self.selected.discard(k))
            row.add_widget(check)
            latency = f'{p["latency"]} ms' if p.get("latency") is not None else "Ping —"
            row.add_widget(Label(text=f'{p["server"]}:{p["port"]}\n{state} • {latency}', halign="right"))
            self.rows.add_widget(row)
        alive = sum(p.get("status") == "متاح TCP" for p in self.items)
        self.summary.text = f"المجموع: {len(self.items)}  |  متاح TCP: {alive}"

    def fetch(self, silent=False):
        if self.fetching:
            return
        self.fetching = True
        if not silent:
            self.status.text = "جارٍ جلب البروكسيات..."
        threading.Thread(target=self.fetch_worker, daemon=True).start()

    def fetch_worker(self):
        found, errors = {}, 0
        for url in SOURCES:
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "TelegramProxyManager/2.0"})
                with urllib.request.urlopen(req, timeout=15) as r:
                    data = r.read(2_000_000).decode("utf-8", "ignore")
                for line_text in data.splitlines():
                    p = parse_proxy(line_text)
                    if p:
                        p["source"] = urllib.parse.urlparse(url).netloc
                        found[pkey(p)] = p
            except Exception:
                errors += 1
        Clock.schedule_once(lambda dt: self.finish_fetch(found, errors), 0)

    def finish_fetch(self, found, errors):
        known = {pkey(p) for p in self.items}
        added = 0
        for k, p in found.items():
            if k not in known:
                p.update(status="غير مفحوص", latency=None)
                self.items.append(p); added += 1
        self.fetching = False
        self.save(); self.render()
        self.status.text = f"تحديث مكتمل: {len(found)} نتيجة، جديد {added}، أخطاء مصادر {errors}"

    def check_all(self):
        if self.testing or not self.items:
            self.status.text = "لا توجد بروكسيات أو الفحص جارٍ بالفعل."
            return
        self.testing = True
        self.status.text = "جارٍ فحص TCP بالتوازي..."
        threading.Thread(target=self.check_worker, daemon=True).start()

    def check_worker(self):
        with ThreadPoolExecutor(max_workers=24) as pool:
            futures = {pool.submit(tcp_test, p): p for p in self.items}
            for future in as_completed(futures):
                p = futures[future]
                try:
                    ok, ms = future.result()
                except Exception:
                    ok, ms = False, None
                p["status"], p["latency"] = ("متاح TCP", ms) if ok else ("غير متاح", None)
        Clock.schedule_once(lambda dt: self.finish_check(), 0)

    def finish_check(self):
        self.testing = False
        self.save(); self.render()
        self.status.text = "اكتمل الفحص والترتيب حسب Ping."

    def selected_items(self):
        return [p for p in self.items if pkey(p) in self.selected]

    def open_proxy(self, p):
        try:
            from jnius import autoclass
            Intent = autoclass("android.content.Intent")
            Uri = autoclass("android.net.Uri")
            Activity = autoclass("org.kivy.android.PythonActivity")
            Activity.mActivity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link(p))))
            self.status.text = "تم إرسال الرابط إلى Telegram."
        except Exception as e:
            self.status.text = "تعذر فتح الرابط: " + str(e)

    def open_selected(self):
        chosen = self.selected_items()
        if chosen:
            self.open_proxy(chosen[0])
        else:
            self.status.text = "حدد بروكسي أولاً."

    def open_fastest(self):
        available = [p for p in self.items if p.get("status") == "متاح TCP" and p.get("latency") is not None]
        if available:
            self.open_proxy(min(available, key=lambda p: p["latency"]))
        else:
            self.status.text = "افحص البروكسيات أولاً؛ لا توجد نتيجة TCP ناجحة."

    def add_manual(self):
        form = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        server = TextInput(hint_text="Server / IP", multiline=False)
        port = TextInput(hint_text="Port", multiline=False, input_filter="int")
        secret = TextInput(hint_text="Secret", multiline=False)
        for field in (server, port, secret):
            form.add_widget(field)
        save_btn = Button(text="حفظ", size_hint_y=None, height=dp(44))
        form.add_widget(save_btn)
        popup = Popup(title="إضافة MTProto", content=form, size_hint=(.92, .55))
        def save(*_):
            p = parse_proxy(f"{server.text}:{port.text}:{secret.text}")
            if not p:
                self.status.text = "بيانات غير صحيحة؛ تحقق من Server وPort وSecret."
                return
            if any(pkey(x) == pkey(p) for x in self.items):
                self.status.text = "البروكسي موجود مسبقاً."
                return
            p.update(source="يدوي", status="غير مفحوص", latency=None)
            self.items.append(p); self.save(); self.render(); popup.dismiss()
        save_btn.bind(on_release=save)
        popup.open()

    def delete_selected(self):
        if not self.selected:
            self.status.text = "حدد بروكسيات للحذف."
            return
        self.items = [p for p in self.items if pkey(p) not in self.selected]
        self.selected.clear(); self.save(); self.render()
        self.status.text = "تم حذف البروكسيات المحددة."

    def export(self):
        path = os.path.join(self.user_data_dir, "telegram_proxies.txt")
        with open(path, "w", encoding="utf-8") as f:
            for p in self.items:
                f.write(link(p) + "\\n")
        self.status.text = "تم حفظ القائمة داخل مجلد بيانات التطبيق."

if __name__ == "__main__":
    ProxyManager().run()
