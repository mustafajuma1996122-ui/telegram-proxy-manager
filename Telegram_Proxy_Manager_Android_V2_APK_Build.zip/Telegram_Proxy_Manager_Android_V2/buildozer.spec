[app]
title = Telegram Proxy Manager
package.name = telegramproxymanager
package.domain = org.mustafa.tools
source.dir = .
source.include_exts = py,kv,png,jpg,atlas,json,txt
version = 2.0.0
requirements = python3,kivy,pyjnius
orientation = portrait
fullscreen = 0
android.permissions = INTERNET,ACCESS_NETWORK_STATE
android.api = 35
android.minapi = 23
android.archs = arm64-v8a, armeabi-v7a

[buildozer]
log_level = 2
warn_on_root = 1
