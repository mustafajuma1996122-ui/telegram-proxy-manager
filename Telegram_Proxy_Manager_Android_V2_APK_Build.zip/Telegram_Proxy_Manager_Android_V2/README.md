# Telegram Proxy Manager Android V2.0

Python + Kivy source project for Android.

Features:
- Fetch public MTProto proxy entries from two configurable public text feeds.
- De-duplicate and store proxy list locally.
- Concurrent TCP reachability checks (24 workers) and latency sorting.
- Open selected proxy or fastest TCP-reachable proxy via tg://proxy.
- Automatic feed refresh every 5 minutes while the app process is running.
- Manual add, delete, search, filter and TXT export.

## Build APK
This ZIP contains source code, not a prebuilt APK. Build on Linux/WSL2 with Java and Android SDK/NDK:
```bash
python3 -m pip install --user buildozer
buildozer android debug
```
The APK will be created in `bin/`.

## Limitations
TCP reachability does not verify the MTProto handshake, secret validity, or Telegram-side connectivity. The app cannot inspect Telegram's internal connection state after handing off the proxy link. Public proxies are untrusted; the app does not request Telegram credentials or verification codes.


## Build automatically on GitHub (without installing Android tools)
1. Create a new GitHub repository.
2. Upload all files and folders from this project ZIP, including the hidden `.github` folder.
3. Open the repository's **Actions** tab.
4. Choose **Build Android APK** and press **Run workflow** (or push to `main`).
5. When the workflow finishes, open its run and download the artifact named `Telegram-Proxy-Manager-APK`.
6. Extract the artifact and install the APK on Android. You may need to allow installation from that source.

The workflow builds a debug APK. For public distribution, create a properly signed release build.
